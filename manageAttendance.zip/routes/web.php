<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EmployeeController;
use App\Http\Controllers\OfficeController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\LeaveController;
use App\Http\Controllers\OffController;
use App\Http\Controllers\PolicyController;
use \App\Http\Controllers\PaymentController;
use App\Http\Controllers\VisitController;
use \App\Http\Controllers\OwnerController;
use \App\Http\Controllers\LunchBreakController;
use \App\Http\Controllers\AdvancePaymentController;
use \App\Http\Controllers\PlanController;
use \App\Http\Controllers\CorrectionNoteController;
use App\Http\Controllers\RequestDemoController;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\AttendanceRecordController;
use App\Http\Controllers\DesignationController;
use App\Http\Controllers\EmployeeRosterController;
use App\Http\Controllers\NewUserLeadController;
use App\Http\Controllers\OfficeAccessController;
use App\Http\Controllers\OldRecordController;
use App\Http\Controllers\DocumentTypeController;
use App\Http\Controllers\LetterTemplateController;
use App\Http\Controllers\EmployeeLetterController;
use Illuminate\Support\Facades\File;
use App\Http\Controllers\LogViewerController;
use App\Http\Controllers\UserActivityController;
use App\Http\Controllers\UserActivityPageController;
use App\Http\Controllers\ChatController;
use App\Http\Controllers\ChatNotificationController;

// Load once from routes/web.php so web/session/CSRF middleware is applied.
Route::middleware('auth')->prefix('chat')->name('chat.')->group(function () {
    Route::get('/notifications/feed', [ChatNotificationController::class, 'feed'])->name('notifications.feed');
    Route::get('/unread-count', [ChatController::class, 'unreadCount'])->name('unread-count');
    Route::get('/', [ChatController::class, 'index'])->name('index');
    Route::post('/start/{user}', [ChatController::class, 'startPrivateChat'])->name('start');
    Route::post('/team', [ChatController::class, 'createTeamChat'])->name('team.create');
    Route::get('/attachments/{message}', [ChatController::class, 'attachment'])->name('attachment');
    Route::get('/{conversation}/messages', [ChatController::class, 'messages'])->name('messages');
    Route::post('/{conversation}/send', [ChatController::class, 'send'])->name('send');
    Route::post('/{conversation}/read', [ChatController::class, 'markRead'])->name('read');
    Route::get('/{conversation}', [ChatController::class, 'show'])->name('show');
});

// Route::middleware('auth')->group(function () {

//     Route::get(
//         '/chat',
//         [ChatController::class, 'index']
//     )->name('chat.index');


//     Route::get(
//         '/chat/{conversation}',
//         [ChatController::class, 'show']
//     )->name('chat.show');


//     Route::post(
//         '/chat/{conversation}/send',
//         [ChatController::class, 'send']
//     )->name('chat.send');


//     Route::get(
//         '/chat/{conversation}/messages',
//         [ChatController::class, 'messages']
//     )->name('chat.messages');


//     Route::get(
//         '/chat/attachment/{message}',
//         [ChatController::class, 'attachment']
//     )->name('chat.attachment');

// });


// Route::middleware('auth')->group(function () {

//     Route::get('/chat', [
//         ChatController::class,
//         'index'
//     ])->name('chat.index');

//     Route::get('/chat/start/{user}', [
//         ChatController::class,
//         'startPrivateChat'
//     ])->name('chat.start');

//     Route::post('/chat/team/create', [
//         ChatController::class,
//         'createTeamChat'
//     ])->name('chat.team.create');

//     Route::get('/chat/{conversation}', [
//         ChatController::class,
//         'show'
//     ])->name('chat.show');

//     Route::post('/chat/{conversation}/send', [
//         ChatController::class,
//         'send'
//     ])->name('chat.send');

//     Route::get('/chat/{conversation}/messages', [
//         ChatController::class,
//         'messages'
//     ])->name('chat.messages');

//     Route::post('/chat/{conversation}/read', [
//         ChatController::class,
//         'markRead'
//     ])->name('chat.read');
// });




Route::post('/new-user-lead/store', [NewUserLeadController::class, 'store'])->name('request.store');

Route::get('privacy-policy', function(){
   return view('privacy-policy');
})->name('privacy-policy');

Route::controller(\App\Http\Controllers\FrontController::class)->group(function(){
    Route::get('/', 'mainpage')->name('mainpage');
    Route::get('/Blogs', 'blogs')->name('blogs');
    Route::get('/blogDetailsPage', 'blogDetailsPage')->name('blogDetailsPage');
    Route::get('/reqDemo', 'reqDemo')->name('reqDemo');
    Route::get('/thankyou', 'thankyou')->name('thankyoupage');
    Route::get('employee-form', 'employeeForm')->name('employee-form');
    Route::post('employee-register', 'employeeRegister')->name('employee-register');
});

Route::controller(RequestDemoController::class)->group(function () {
    Route::get('request/index', 'index')->name('request.index');
    Route::post('request/store', 'store')->name('request.demo.store');
    Route::get('request/delete/{appointment}', 'delete')->name('request.delete');
});




//Route::get('change-pass', [HomeController::class, 'changePass'])->name('change-pass');

Auth::routes();

Route::get('/login/otp', [App\Http\Controllers\Auth\LoginController::class, 'showOtpForm'])->name('login.otp');
Route::post('/login/otp', [App\Http\Controllers\Auth\LoginController::class, 'verifyOtp'])->name('login.otp.verify');


Route::middleware(['auth', 'track.activity', 'active.office'])->group(function (){


    // Route::prefix('user-activity')
    //     ->name('user-activity.')
    //     ->group(function () {
    //         Route::post(
    //             'heartbeat',
    //             [UserActivityController::class, 'heartbeat']
    //         )->name('heartbeat');

    //         Route::post(
    //             'end',
    //             [UserActivityController::class, 'end']
    //         )->name('end');

    //         Route::get(
    //             '/',
    //             [UserActivityPageController::class, 'index']
    //         )->name('index');

    //         Route::get(
    //             'user/{user}',
    //             [UserActivityPageController::class, 'show']
    //         )->name('show');
    //     });


    Route::prefix('user-activity')
    ->name('user-activity.')
    ->group(function () {

        Route::post(
            'heartbeat',
            [UserActivityController::class, 'heartbeat']
        )->name('heartbeat');

        Route::post(
            'end',
            [UserActivityController::class, 'end']
        )->name('end');

        Route::get(
            '/',
            [UserActivityPageController::class, 'index']
        )->name('index');

        Route::delete(
            'clear',
            [UserActivityPageController::class, 'clearRange']
        )->name('clear');

        Route::delete(
            'user/{user}/clear',
            [UserActivityPageController::class, 'clearUserRange']
        )->name('user.clear');

        Route::delete(
            'session/{activity}',
            [UserActivityPageController::class, 'destroySession']
        )->name('session.destroy');

        Route::get(
            'user/{user}',
            [UserActivityPageController::class, 'show']
        )->name('show');
    });


    Route::resource('document-types', DocumentTypeController::class);

    Route::resource('letter-templates', LetterTemplateController::class);

    Route::get('employee-letters/templates/get', [EmployeeLetterController::class, 'getTemplates'])
        ->name('employee-letters.get-templates');

    Route::get('employee-letters/user-data/{user}', [EmployeeLetterController::class, 'getUserData'])
        ->name('employee-letters.get-user-data');

    Route::get('employee-letters/{employeeLetter}/print', [EmployeeLetterController::class, 'print'])
        ->name('employee-letters.print');

    Route::get('employee-letters/{employeeLetter}/preview', [EmployeeLetterController::class, 'preview'])
        ->name('employee-letters.preview');

    Route::resource('employee-letters', EmployeeLetterController::class);


    //Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
    Route::get('/home', [App\Http\Controllers\DashboardController::class, 'dashboard'])->name('home');


    Route::prefix('attendance')->name('attendance.')->controller(App\Http\Controllers\AttendanceRecordController::class)->group(function(){
        Route::get('index/{user?}', 'index')->name('index');
        Route::post('check_in/{user?}', 'checkIn')->name('check_in');
        Route::post('check_out/{user?}', 'checkOut')->name('check_out');
        Route::get('form/{form_type}/{user?}', 'form')->name('form');
        Route::get('day-wise', 'dayWise')->name('day-wise');
        Route::post('note/{record}', 'addNote')->name('note');
        Route::post('user/note/{record}/{type}', 'userNote')->name('user.note');
        Route::get('user/note/response/{record}/{type}/{status}', 'userNoteResponse')->name('user.note.response');
        Route::get('reason/form/{type}/{record}', 'reasonFormLoad')->name('reason.form');
        Route::post('store', 'store')->name('store');
    });

    Route::get('setting/instruction', function (){
        return view('dashboard.settingInstruction');
    })->name('setting.instruction');

    Route::get(
            '/employees/next-employee-id/{office}',
            [EmployeeController::class, 'nextEmployeeId']
        )->name('employee.next-id');

    Route::prefix('employee')->name('employee.')->group(function (){
        Route::get('/', [EmployeeController::class, 'index'])->name('index');
        Route::get('create', [EmployeeController::class, 'create'])->name('create');
        Route::post('store', [EmployeeController::class, 'store'])->name('store');
        Route::get('edit/{employee}', [EmployeeController::class, 'edit'])->name('edit');
        Route::post('update/{employee}', [EmployeeController::class, 'update'])->name('update');
        Route::post('delete/{employee}', [EmployeeController::class, 'delete'])->name('delete');
        Route::get('profile/{user}', [HomeController::class, 'profile'])->name('profile');
        Route::get('attendance', [EmployeeController::class, 'employeeAttendance'])->name('attendance');
        Route::get('status/{employee}', [EmployeeController::class, 'status'])->name('status');
        Route::get('permission/{user}', [EmployeeController::class, 'permission'])->name('permission');
        Route::get('permissionRemove/{permission}/{user}', [EmployeeController::class, 'permissionRemove'])->name('permissionRemove');
    });

    Route::resource('departments', \App\Http\Controllers\DepartmentController::class);

    Route::resource(
        'designations',
        DesignationController::class
    );


    Route::patch(
        'designations/{designation}/toggle-status',
        [
            DesignationController::class,
            'toggleStatus'
        ]
    )->name(
        'designations.toggle-status'
    );


    Route::prefix('owner')->name('owner.')->group(function(){
       Route::get('/', [OwnerController::class, 'index'])->name('index');
       Route::get('create', [OwnerController::class, 'create'])->name('create');
       Route::post('store', [OwnerController::class, 'store'])->name('store');
       Route::get('edit/{owner}', [OwnerController::class, 'edit'])->name('edit');
       Route::post('update/{owner}', [OwnerController::class, 'update'])->name('update');
       Route::post('delete/{owner}', [OwnerController::class, 'delete'])->name('delete');
       Route::get('status/{owner}', [OwnerController::class, 'status'])->name('status');
       Route::get('plan/{owner}', [PlanController::class, 'ownerPlan'])->name('plan');
    });

    Route::prefix('plan')->name('plan.')->group(function (){
        Route::get('create/{owner}', [PlanController::class, 'create'])->name('create');
        Route::post('store/{owner}', [PlanController::class, 'store'])->name('store');
        Route::get('edit/{plan}', [PlanController::class, 'edit'])->name('edit');
        Route::post('update/{plan}', [PlanController::class, 'update'])->name('update');
        Route::get('status/{plan}', [PlanController::class, 'status'])->name('status');
        Route::post('delete/{plan}', [PlanController::class, 'delete'])->name('delete');
    });

    Route::prefix('break')->name('break.')->group(function(){
        Route::get('/', [LunchBreakController::class, 'index'])->name('index');
        Route::post('start/{employee?}', [LunchBreakController::class, 'start'])->name('start');
        Route::post('stop/{break}/{employee?}', [LunchBreakController::class, 'stop'])->name('stop');
        Route::get('form/{employee?}/{break?}', [LunchBreakController::class, 'form'])->name('form');
    });

    Route::post('profile/update/{user}', [HomeController::class, 'updateProfile'])->name('profile.update');

    // DEMO TESTING MAIL


    Route::prefix('office')->name('office.')->group(function(){
       Route::get('/', [OfficeController::class, 'index'])->name('index');
       Route::get('create', [OfficeController::class, 'create'])->name('create');
       Route::get('edit/{office}', [OfficeController::class, 'edit'])->name('edit');
       Route::post('store', [OfficeController::class, 'store'])->name('store');
       Route::post('update/{office}', [OfficeController::class, 'update'])->name('update');
       Route::get('delete/{office}', [OfficeController::class, 'delete'])->name('delete');
       Route::get('status/{office}', [OfficeController::class, 'status'])->name('status');
       Route::get('detail/{office}', [OfficeController::class, 'detail'])->name('detail');
    });


     Route::post('/office/switch/{office}', [OfficeAccessController::class, 'switchOffice'])
        ->name('office.switch');

    Route::post('/office/clear-switch', [OfficeAccessController::class, 'clearSwitch'])
        ->name('office.clearSwitch');

    Route::prefix('off_policy')->name('off_policy.')->controller(\App\Http\Controllers\OfficeOffPolicyController::class)->group(function(){
       Route::get('/', 'index')->name('index');
       Route::get('create', 'create')->name('create');
       Route::post('store', 'store')->name('store');
    });

    Route::prefix('payment')->name('payment.')->group(function(){
        Route::get('/', [PaymentController::class, 'index'])->name('index');
       Route::get('paymentForm/{payment}', [PaymentController::class, 'paymentForm'])->name('paymentForm');
       Route::post('add/{payment}', [PaymentController::class, 'addPayment'])->name('add');
       Route::get('advance/{office}', [PaymentController::class, 'advance'])->name('advance');
    });



    Route::get('/userprofile/{user}', [HomeController::class, 'profile'])->name('userprofile');
    Route::post('userPassword/{user}', [HomeController::class, 'changePassword'])->name('userPassword');

    Route::prefix('leave')->name('leave.')->group(function(){
        Route::get('/', [LeaveController::class, 'index'])->name('index');
        Route::get('create/{employeeId?}', [LeaveController::class, 'create'])->name('create');
        Route::post('store', [LeaveController::class, 'store'])->name('store');
        Route::get('status/{leave}/{status}/{type?}', [LeaveController::class, 'status'])->name('status');
        Route::get('show/{leave}', [LeaveController::class, 'show'])->name('show');
        Route::post('response/{leave}', [LeaveController::class, 'response'])->name('response');
    });

    Route::prefix('off')->name('off.')->group(function(){
       Route::get('/', [OffController::class, 'index'])->name('index');
       Route::get('create', [OffController::class, 'create'])->name('create');
       Route::post('store', [OffController::class, 'store'])->name('store');
       Route::get('edit/{off}', [OffController::class, 'edit'])->name('edit');
       Route::post('update/{off}', [OffController::class, 'update'])->name('update');
       Route::post('delete/{off}', [OffController::class, 'delete'])->name('delete');
    });

    Route::prefix('policy')->name('policy.')->group(function(){
        Route::get('/', [PolicyController::class, 'index'])->name('index');
        Route::get('create', [PolicyController::class, 'create'])->name('create');
        Route::post('store', [PolicyController::class, 'store'])->name('store');
        Route::get('edit/{policy}', [PolicyController::class, 'edit'])->name('edit');
        Route::post('update/{policy}', [PolicyController::class, 'update'])->name('update');
        Route::post('delete/{policy}', [PolicyController::class, 'delete'])->name('delete');
        Route::get('read/{policy?}', [PolicyController::class, 'read'])->name('read');
        Route::get('accept/{policy}', [PolicyController::class, 'accept'])->name('accept');
    });

    Route::prefix('reports')->name('reports.')->group(function(){
       Route::get('/', [\App\Http\Controllers\FinalReportController::class, 'index'])->name('index');
    });

    Route::prefix('info')->name('info.')->group(function(){
       Route::get('create', [\App\Http\Controllers\UserAdditionalInformationController::class, 'create'])->name('create');
       Route::post('store', [\App\Http\Controllers\UserAdditionalInformationController::class, 'store'])->name('store');
    });

    Route::prefix('visit')->name('visit.')->group(function(){
       Route::get('/', [VisitController::class, 'index'])->name('index');
       Route::get('create', [VisitController::class, 'create'])->name('create');
       Route::post('store', [VisitController::class, 'store'])->name('store');
       Route::get('edit/{visit}', [VisitController::class, 'edit'])->name('edit');
       Route::post('update/{visit}', [VisitController::class, 'update'])->name('update');
       Route::get('delete/{visit}', [VisitController::class, 'delete'])->name('delete');
       Route::get('status/{visit}/{status}', [VisitController::class, 'status'])->name('status');
       Route::get('paid/{visit}', [VisitController::class, 'pay'])->name('paid');
    });

    Route::prefix('salary')->name('salary.')->group(function(){
       Route::get('/', [\App\Http\Controllers\SalaryController::class, 'index'])->name('index');
       Route::get('status/{salary}', [\App\Http\Controllers\SalaryController::class, 'status'])->name('status');
       Route::post('pay/{salary}', [\App\Http\Controllers\SalaryController::class, 'paidAmount'])->name('pay');
       Route::get('setupForm/{employee}', [\App\Http\Controllers\SalaryController::class, 'salarySetupForm'])->name('setupForm');
       Route::post('informationStore/{employee}/{userSalary?}', [\App\Http\Controllers\SalaryController::class, 'userSalaryInformationStore'])->name('informationStore');
       Route::get('slip/{salary}', [\App\Http\Controllers\SalaryController::class, 'salarySlip'])->name('slip');
    });

    Route::prefix('recycle')->name('recycle.')->group(function(){
        Route::get('/', [\App\Http\Controllers\RecycleController::class, 'index'])->name('index');
        Route::get('user/delete/{user}', [\App\Http\Controllers\RecycleController::class, 'userDelete'])->name('user.delete');
        Route::get('user/restore/{user}', [\App\Http\Controllers\RecycleController::class, 'userRestore'])->name('user.restore');
    });

    Route::get('manual/entry/form', [AttendanceRecordController::class, 'manualEntryForm'])->name('manual.entry.form');

    Route::prefix('permission')->name('permission.')->group(function(){
       Route::get('/', [\App\Http\Controllers\PermissionController::class, 'index'])->name('index');
       Route::get('create', [\App\Http\Controllers\PermissionController::class, 'create'])->name('create');
       Route::post('give', [\App\Http\Controllers\PermissionController::class, 'givePermission'])->name('give');
       Route::post('store', [\App\Http\Controllers\PermissionController::class, 'store'])->name('store');
    });

    Route::prefix('advance')->name('advance.')->group(function(){
        Route::get('/', [AdvancePaymentController::class, 'index'])->name('index');
        Route::get('create/{user?}', [AdvancePaymentController::class, 'create'])->name('create');
        Route::get('request', [AdvancePaymentController::class, 'request'])->name('request');
        Route::post('request/store', [AdvancePaymentController::class, 'requestStore'])->name('request.store');
        Route::post('store', [AdvancePaymentController::class, 'store'])->name('store');
        Route::get('status/{payment}', [AdvancePaymentController::class, 'status'])->name('status')->can('change advance payment status');
    });


    Route::prefix('role')->name('role.')->group(function(){
        Route::get('/', [\App\Http\Controllers\RoleController::class, 'index'])->name('index');
        Route::get('create', [\App\Http\Controllers\RoleController::class, 'create'])->name('create');
        Route::post('store', [\App\Http\Controllers\RoleController::class, 'store'])->name('store');
        Route::get('delete/{role}', [\App\Http\Controllers\RoleController::class, 'delete'])->name('delete');
        Route::get('permission/{role}', [\App\Http\Controllers\RoleController::class, 'permission'])->name('permission');
        Route::get('permissionRemove/{permission}/{role}', [\App\Http\Controllers\RoleController::class, 'permissionRemove'])->name('permissionRemove');
    });

    Route::prefix('note')->name('note.')->group(function(){
       Route::get('/', [\App\Http\Controllers\NoteController::class, 'index'])->name('index');
       Route::get('create', [\App\Http\Controllers\NoteController::class, 'create'])->name('create');
       Route::post('store', [\App\Http\Controllers\NoteController::class, 'store'])->name('store');
        Route::get('status/{note}', [\App\Http\Controllers\NoteController::class, 'status'])->name('status');
        Route::get('delete/{note}', [\App\Http\Controllers\NoteController::class, 'delete'])->name('delete');
    });

    Route::prefix('correctionNote')->name('correctionNote.')->group(function(){
        Route::get('create/{record}/{note?}', [CorrectionNoteController::class, 'create'])->name('create');
        Route::post('store/{record}', [CorrectionNoteController::class, 'store'])->name('store');
    });

    Route::prefix('half-day')->name('half-day.')->controller(\App\Http\Controllers\HalfDayController::class)->group(function(){
       Route::get('/', 'index')->name('index');
       Route::get('create/{employee?}', 'create')->name('create');
       Route::post('store', 'store')->name('store');
       Route::post('status/{halfDay}', 'status')->name('status');
    });



        Route::get('/old-attendance-records', [OldRecordController::class, 'index'])
            ->name('old-attendance.index');

        Route::get('/old-attendance-records/{record}', [OldRecordController::class, 'show'])
            ->name('old-attendance.show');

        Route::delete('/old-attendance-records/{record}', [OldRecordController::class, 'destroy'])
            ->name('old-attendance.destroy');

        Route::delete('/old-attendance-records-delete-all', [OldRecordController::class, 'destroyOldRecords'])
            ->name('old-attendance.destroy-old-records');




    Route::middleware(['auth'])->prefix('rosters')->name('rosters.')->group(function () {
        Route::post('/store', [EmployeeRosterController::class, 'store'])->name('store');
        Route::post('/bulk-store', [EmployeeRosterController::class, 'bulkStore'])->name('bulk-store');
        Route::get('/monthly', [EmployeeRosterController::class, 'monthly'])->name('monthly');
        Route::get('/employee/{employee}', [EmployeeRosterController::class, 'employeeRoster'])->name('employee');
        Route::get('/month-grid', [EmployeeRosterController::class, 'monthGrid'])->name('month-grid');
        Route::get('/today-status', [EmployeeRosterController::class, 'todayStatus'])->name('today-status');
        Route::post('/generate-month', [EmployeeRosterController::class, 'generateMonth'])->name('generate-month');
        Route::post('/delete', [EmployeeRosterController::class, 'delete'])->name('delete');

        Route::get('/', [EmployeeRosterController::class, 'index'])->name('index');
        Route::post('/ajax-upsert', [EmployeeRosterController::class, 'ajaxUpsert'])->name('ajax-upsert');
    });






    // hello how are you mera naam hai jolly
    // web.php

// OfficeController.php
    Route::get('note/get-office-role-and-employee/{officeId}', [\App\Http\Controllers\NoteController::class, 'getOfficeRoleAndEmployee']);


    Route::get('/foo', function () {
        $exitCode = Artisan::call('storage:link');
        if ($exitCode === 0) {
            return 'Success';
        } else {
            return 'Failed'; // You can customize this message as needed
        }
    });




Route::prefix('logs')
    ->name('logs.')
    ->controller(LogViewerController::class)
    ->group(function () {

        Route::get('/', 'index')
            ->name('index');

        Route::get('/download/{file}', 'download')
            ->where('file', '[A-Za-z0-9._-]+')
            ->name('download');

        Route::post('/clear/{file}', 'clear')
            ->where('file', '[A-Za-z0-9._-]+')
            ->name('clear');

        Route::delete('/delete/{file}', 'destroy')
            ->where('file', '[A-Za-z0-9._-]+')
            ->name('destroy');

        Route::delete('/delete-all', 'destroyAll')
            ->name('destroy-all');
    });

});
