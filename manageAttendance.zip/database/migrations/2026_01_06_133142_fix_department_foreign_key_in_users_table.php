<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        Schema::table('users', function (Blueprint $table) {

            // 🔥 Purana galat FK hatao
            $table->dropForeign(['department_id']);

            // ✅ Sahi FK lagao
            $table->foreign('department_id')
                ->references('id')
                ->on('departments')
                ->nullOnDelete();
        });
    }

    public function down()
    {
        Schema::table('users', function (Blueprint $table) {

            $table->dropForeign(['department_id']);

            // (optional) wapas users table pe lagana ho to
            $table->foreign('department_id')
                ->references('id')
                ->on('users')
                ->nullOnDelete();
        });
    }
};
